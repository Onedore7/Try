package com.hexated

import com.lagradost.cloudstream3.extractors.XStreamCdn

class Lkctwoone: XStreamCdn() {
    override val name: String = "LKC21"
    override val mainUrl: String = "https://lkc21.net"
}